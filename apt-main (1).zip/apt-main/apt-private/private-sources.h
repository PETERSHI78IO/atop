#ifndef APT_PRIVATE_SOURCES_H
#define APT_PRIVATE_SOURCES_H

#include <apt-pkg/macros.h>

class CommandLine;

APT_PUBLIC bool EditSources(CommandLine &CmdL);

#endif
